package edu.cas.services;

import java.util.ArrayList;

import edu.cas.dto.Order;
import edu.cas.dto.Product;
import edu.cas.dto.User;

public interface CasService{

	public String addUser(User user);

	public String loginSubmit(User user);

	public ArrayList<Product> getProducts();

	public User getUser(String userid);

	public String saveUser(User user);

	public Order createOrder(String userid, String productid, String orderqty, String totalprice, String orderprice);

	public ArrayList<Order> getOrderHistory(String userid);
	
	
}