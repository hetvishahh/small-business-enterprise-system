package edu.cas.daoimpl;

import java.sql.Blob;
import java.util.ArrayList;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import javax.sql.RowSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import edu.cas.dao.CasDao;
import edu.cas.dto.Order;
import edu.cas.dto.OrderDetails;
import edu.cas.dto.Product;
import edu.cas.dto.User;

@Repository
public class CasDaoImpl extends JdbcDaoSupport implements CasDao{
	
	@Autowired
	DataSource datasource;
	
	@PostConstruct
	private void initialize() {
		setDataSource(datasource);
	}


	@Override
	public  String addUser(User user) {
		// TODO Auto-generated method stub
		
		//System.out.println(user.toString());
		//Check User Name Exists
		String sql = "select * from cass.user where user_name=?";
		SqlRowSet rs =  getJdbcTemplate().queryForRowSet(sql, new Object[] {user.getUser_name()});
		
		if(rs.next()) {
			System.out.println("User exist");
			 return "User Name already exists";
		}else {
			System.out.println("User does not exist");
			sql = "INSERT INTO cass.user (user_id,user_roleid, user_name, user_password, user_firstname, user_lastname, user_address, user_emailid) "
					+ "values (nextval('cass.user_id'),?,?,?,?,?,?,?) ";
			int iupdcnt = getJdbcTemplate().update(sql, new Object[] {
				user.getUser_roleid(), user.getUser_name(), user.getUser_password(), user.getUser_firstname(), user.getUser_lastname(), user.getUser_address(), user.getUser_emailid()	
			});
			
			return "Success";
		}
	};
		
		@Override
		public  String loginSubmit(User user) {
			// TODO Auto-generated method stub
			
			//System.out.println(user.toString());
			//Check User Name Exists
			String sql = "select * from cass.user, cass.role  where user_name=? and cass.user.user_roleid = cass.role.role_id";
			SqlRowSet rs =  getJdbcTemplate().queryForRowSet(sql, new Object[] {user.getUser_name()});
			
			if(rs.next()) {
				System.out.println("User Login");
				String password = rs.getString("user_password");
				if(user.getUser_password().equals(password)) {
					user.setUser_id(rs.getInt("user_id"));
					user.setUser_roleid(rs.getInt("user_roleid"));
					user.setUser_firstname(rs.getString("user_firstname"));
					user.setUser_lastname(rs.getString("user_lastname"));
					user.setUser_address(rs.getString("user_address"));
					user.setUser_emailid(rs.getString("user_emailid"));
					user.setUser_rolename(rs.getString("role_name"));
					return "Success";
				}else {
					return "User credentials do not match";
				}
			}else {
				System.out.println("User does not exist");			
				return "User does not exist";
			}
	};

	public ArrayList<Product> getProducts(){		
		ArrayList<Product> productlist = new ArrayList<Product>();
		String sql = "select product_id, product_name, product_price, product_quantity, encode(product_image, 'base64') as product_image from cass.products where product_quantity>0";
		SqlRowSet rs =  getJdbcTemplate().queryForRowSet(sql);
		while(rs.next()) {
			Product product = new Product();
			product.setProduct_id(rs.getInt("product_id"));
			product.setProduct_name(rs.getString("product_name"));
			product.setProduct_price(rs.getString("product_price"));
			product.setProduct_quantity(rs.getString("product_quantity"));
			product.setOrder_quantity(0);
			product.setProduct_image_stringbase64(rs.getString("product_image"));
			productlist.add(product);
		}	
		return productlist;
	};	
	
	@Override
	public  User getUser(String userid) {
		// TODO Auto-generated method stub
		User user = new User();
		int uid = 0;
		try { uid = Integer.parseInt(userid); }catch(Exception e) {}
		
		String sql = "select * from cass.user, cass.role  where user_id=? and cass.user.user_roleid = cass.role.role_id";
		SqlRowSet rs =  getJdbcTemplate().queryForRowSet(sql, new Object[] {uid});
		
		if(rs.next()) {
			System.out.println("get User");
			user.setUser_id(rs.getInt("user_id"));
			user.setUser_roleid(rs.getInt("user_roleid"));
			user.setUser_firstname(rs.getString("user_firstname"));
			user.setUser_lastname(rs.getString("user_lastname"));
			user.setUser_name(rs.getString("user_name"));
			user.setUser_address(rs.getString("user_address"));
			user.setUser_emailid(rs.getString("user_emailid"));		
			user.setUser_rolename(rs.getString("role_name"));
		}
		
		return user;
	};
	
	@Override
	public  String saveUser(User user) {
		// TODO Auto-generated method stub

			System.out.println("User update ");
			String sql = "UPDATE cass.user set  user_roleid = ?, user_password = ?, user_firstname = ?, user_lastname = ?, user_address = ?, user_emailid = ?  where user_id = ? " ;
			int iupdcnt = getJdbcTemplate().update(sql, new Object[] {
				user.getUser_roleid(), user.getUser_password(), user.getUser_firstname(), user.getUser_lastname(), user.getUser_address(), user.getUser_emailid(), user.getUser_id()	
			});
			
			return "Success";
		
	};
	
	
	public Order createOrder(String userid, String productid, String orderqty, String totalprice, String orderprice) {
		Order order = new Order();
		//System.out.println("createOrder " +  userid );
		//System.out.println("createOrder " + productid );
		//System.out.println("createOrder " + orderqty );
		//System.out.println("createOrder " + totalprice );
		
		
		String[] productarray = productid.split(","); 
		String[] orderqtyarray = orderqty.split(","); 
		String[] totalpricearray = totalprice.split(","); 
		String[] useridarray = userid.split(","); 
		int orderid = 0;
		
		//Get Order Sequence
		String sql = "select nextval('cass.order_id') orderid";
		SqlRowSet rs =  getJdbcTemplate().queryForRowSet(sql);
		
		if(rs.next()) {
			 orderid = rs.getInt("orderid");
		}
		
		//System.out.println("orderid " + orderid );
		
		order.setOrder_id(orderid);
		
		
		
		//Create Order
		sql = "INSERT INTO cass.orders (order_id, order_status, user_id, order_date, order_total) "
				+ "values (?,?,?,current_timestamp,?) ";
		int iupdcnt = getJdbcTemplate().update(sql, new Object[] {
			orderid, "Created", Integer.parseInt(useridarray[0]), Float.parseFloat(orderprice)
		});
		
		sql = "select user_firstname, user_lastname, order_status,  to_char(order_date, 'mm/dd/yyyy hh24:mi:ss') as order_date, order_total from cass.orders , cass.user where cass.orders.order_id = ? and cass.orders.user_id = cass.user.user_id";
		rs =  getJdbcTemplate().queryForRowSet(sql, new Object[] {
			orderid
		});
		while(rs.next()) {
			order.setOrder_status(rs.getString("order_status"));	
			order.setOrder_date(rs.getString("order_date"));
			order.setOrder_total(rs.getString("order_total"));
			order.setUser_name(rs.getString("user_firstname") + ", " + rs.getString("user_lastname"));
		}	
		//Create Order details		
		ArrayList<OrderDetails> orderdetailslist = new ArrayList<OrderDetails>();
		for( int i = 0; i <= productarray.length - 1; i++)
		{
		   if (Integer.parseInt(orderqtyarray[i]) > 0) {
				sql = "INSERT INTO cass.order_details (order_details_id, order_id, product_id, order_quantity, total_price) "
						+ "values (nextval('cass.order_details_id'),?,?,?,?) ";
				iupdcnt = getJdbcTemplate().update(sql, new Object[] {
					orderid, Integer.parseInt(productarray[i]), Integer.parseInt(orderqtyarray[i]),  Float.parseFloat(totalpricearray[i])
				});
		   }
			
		}
		
		sql = "select product_name, order_quantity, total_price, encode(product_image, 'base64') as product_image  from cass.order_details , cass.products where  order_id = ? and cass.order_details.product_id = cass.products.product_id";
		rs =  getJdbcTemplate().queryForRowSet(sql, new Object[] {
			orderid
		});
		while(rs.next()) {
			OrderDetails orderdetails = new OrderDetails();
			orderdetails.setProduct_name(rs.getString("product_name"));	
			orderdetails.setOrder_quantity(rs.getString("order_quantity"));
			orderdetails.setTotal_price(rs.getString("total_price"));
			orderdetails.setProduct_image_stringbase64(rs.getString("product_image"));
			orderdetailslist.add(orderdetails);
		}	
		order.setOrderdetailslist(orderdetailslist);
		
		return order;		
	};	
	
	public ArrayList<Order> getOrderHistory(String userid){
		ArrayList<Order> orders = new ArrayList<Order>();
		
		String sql = "select user_firstname, user_lastname, order_id , order_status,  to_char(order_date, 'mm/dd/yyyy hh24:mi:ss') as order_date ,  to_char(ship_date, 'mm/dd/yyyy hh24:mi:ss') as ship_date, order_total from cass.orders, cass.user where cass.orders.user_id = ? and cass.orders.user_id = cass.user.user_id order by order_id desc";
		SqlRowSet rs =  getJdbcTemplate().queryForRowSet(sql, new Object[] {
				Integer.parseInt(userid)
		});
		while(rs.next()) {
			Order order = new Order();
			order.setOrder_id(rs.getInt("order_id"));
			order.setOrder_status(rs.getString("order_status"));	
			order.setOrder_date(rs.getString("order_date"));
			order.setShip_date(rs.getString("ship_date"));
			order.setOrder_total(rs.getString("order_total"));
			order.setUser_name(rs.getString("user_firstname") + ", " + rs.getString("user_lastname"));
			
			ArrayList<OrderDetails> orderdetailslist = new ArrayList<OrderDetails>();
			String sql1 = "select product_name, order_quantity, total_price, encode(product_image, 'base64') as product_image from cass.order_details , cass.products where  order_id = ? and cass.order_details.product_id = cass.products.product_id";
			SqlRowSet rs1 =  getJdbcTemplate().queryForRowSet(sql1, new Object[] {
				order.getOrder_id()
			});
			while(rs1.next()) {
				OrderDetails orderdetails = new OrderDetails();
				orderdetails.setProduct_name(rs1.getString("product_name"));	
				orderdetails.setOrder_quantity(rs1.getString("order_quantity"));
				orderdetails.setTotal_price(rs1.getString("total_price"));
				orderdetails.setProduct_image_stringbase64(rs1.getString("product_image"));
				orderdetailslist.add(orderdetails);
			}	
			
			order.setOrderdetailslist(orderdetailslist);
			orders.add(order);
		}	
		
		return orders;
	}
}