package edu.cas.serviceimpl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.cas.dao.CasDao;
import edu.cas.dto.Product;
import edu.cas.dto.User;
import edu.cas.services.CasService;
import edu.cas.dto.Order;

@Service
public class CasServiceImpl implements CasService{
	
	@Autowired
	private CasDao casdao;

	@Override
	public String  addUser(User user) {
		return casdao.addUser(user);
		
	};

	@Override
	public String loginSubmit(User user) {
		return casdao.loginSubmit(user);

	}
	
	@Override
	public ArrayList<Product> getProducts(){
		return casdao.getProducts();
	}
	
	@Override
	public User getUser(String userid){
		return casdao.getUser(userid);
	}
	
	@Override
	public String saveUser(User user) {
		return casdao.saveUser(user);
	};
	
	@Override
	public Order createOrder(String userid, String productid, String orderqty, String totalprice, String orderprice) {
		return casdao.createOrder(userid, productid, orderqty, totalprice, orderprice);
	};
	
	@Override
	public ArrayList<Order> getOrderHistory(String userid){
		return casdao.getOrderHistory(userid);
	};
	
}
