package edu.cas.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import edu.cas.dto.Order;
import edu.cas.dto.Product;
import edu.cas.dto.User;
import edu.cas.services.CasService;

@Controller
public class CasController {
	
	@Autowired
	private CasService casservice;
	
	@RequestMapping("/")
	public String home() {
		System.out.println("Going home...");
		return "index";
	}
	
	@GetMapping("/register")
	public String showForm(Model model) {
		User user = new User();
		user.setUser_roleid(2);
		model.addAttribute("user", user);
		
		/*
		 * List<String> professionList = Arrays.asList("Developer", "Designer",
		 * "Tester", "Architect"); model.addAttribute("professionList", professionList);
		 */
		
		return "register_form";
	}
	
	@PostMapping("/register")
	public String AddUser(Model model, @ModelAttribute("user") User user) {
		System.out.println(user.toString());
		
		String sreturn = casservice.addUser(user);
		System.out.println("sreturn: " + sreturn);
		if (!sreturn.equalsIgnoreCase("Success")) {	
			model.addAttribute("errMessage" , sreturn);
			return "register_form";
		}else return "register_success";
	}
	
	@GetMapping("/login")
	public String loginForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		
		return "login";
	}
	
	@PostMapping("/login")
	public String loginSubmit(Model model, @ModelAttribute("user") User user) {
		System.out.println(user.toString());
		
		String sreturn = casservice.loginSubmit(user);
		System.out.println("sreturn: " + sreturn);
		if (!sreturn.equalsIgnoreCase("Success")) {	
			model.addAttribute("errMessage" , sreturn);
			return "login";
		}else return "welcome";
	}
	
	@GetMapping("/logout")
	public String logoutForm(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		
		return "login";
	}
	
	@RequestMapping(value = "/home", method = RequestMethod.POST)
	public String welcomeHome(Model model, @RequestParam("user_id") String userid) {
			
		System.out.println("userid: " + userid);
		User user = casservice.getUser(userid);
		model.addAttribute("user", user);
		
		return "welcome";
	}
	
	@RequestMapping(value = "/profile", method = RequestMethod.POST)
	public String getUser(Model model, @RequestParam("user_id") String userid) {
			
		System.out.println("userid: " + userid);
		User user = casservice.getUser(userid);
		model.addAttribute("user", user);
		
		return "profile";
	}
	
	@RequestMapping(value = "/shop", method = RequestMethod.POST)
	public String getProducts(Model model, @RequestParam("user_id") String userid) {
		ArrayList<Product> products = casservice.getProducts();
		model.addAttribute("products", products);
		
		System.out.println("shop: " + userid);
		User user = casservice.getUser(userid);
		model.addAttribute("user", user);
		
		return "shop";
	}
	
	@PostMapping("/saveuser")
	public String saveUser(Model model, @ModelAttribute("user") User user) {
		System.out.println(user.toString());
		
		String sreturn = casservice.saveUser(user);
		System.out.println("sreturn: " + sreturn);
		if (!sreturn.equalsIgnoreCase("Success")) {	
			model.addAttribute("errMessage" , sreturn);
			model.addAttribute("user", user);
			return "profile";
		}else {
			model.addAttribute("successMessage" , "User profile saved successfully");
			model.addAttribute("user", user);
			return "profile";
		}
	}
	
	@PostMapping("/order")
	public String AddOrder(Model model, @RequestParam("user_id") String userid, @RequestParam("product_id") String productid, @RequestParam("order_quantity") String orderqty, @RequestParam("totalprice") String totalprice, @RequestParam("orderprice") String orderprice) {
		System.out.println( userid );
		System.out.println( productid );
		System.out.println( totalprice);	
		System.out.println( orderqty);	
		System.out.println( orderprice);	
			
		Order order = casservice.createOrder(userid, productid, orderqty, totalprice, orderprice);
		model.addAttribute("successMessage" , "Order created successfully");
		model.addAttribute("order", order);
		model.addAttribute("orderdetails", order.getOrderdetailslist());
		
		String[] useridarray = userid.split(","); 
		
		User user = casservice.getUser(useridarray[0]);
		model.addAttribute("user", user);
		
		return "orderconfirmation";

	}
	
	@RequestMapping(value = "/orderhistory", method = RequestMethod.POST)
	public String getOrderHistory(Model model, @RequestParam("user_id") String userid) {
		ArrayList<Order> orders = casservice.getOrderHistory(userid);
		model.addAttribute("orders", orders);
		
		User user = casservice.getUser(userid);
		model.addAttribute("user", user);
		
		return "orderhistory";
	}
}
